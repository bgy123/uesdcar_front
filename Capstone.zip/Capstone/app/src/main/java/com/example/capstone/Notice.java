package com.example.capstone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class Notice extends AppCompatActivity {

    //스피너 데이터를 저장할 ArrayList
    ArrayList<String> notice_model = new ArrayList<>();
    ArrayList<String> notice_caryear = new ArrayList<>();
    ArrayList<String> notice_distance = new ArrayList<>();
    ArrayList<String> notice_price = new ArrayList<>();

    //알람데이터 저장할 변수
    ArrayList<String> box = new ArrayList<String>();
    LinearLayout notice_linear;
    //동적배열
    ArrayList<TextView> dynamic_text = new ArrayList();
    ArrayList<LinearLayout> dynamic_layout = new ArrayList();
    ArrayList<Button> dynamic_button = new ArrayList();

    Button addbtn;
    int noticecount = 0;

    //스피너 설정
    Spinner spinner_model,
            spinner_caryer_from, spinner_caryer_to,
            spinner_distance_from, spinner_distance_to,
            spinner_price_from, spinner_price_to;

    Spinner[] setspinner = new Spinner[10];

    int[] setspinnerid = {R.id.model_name,
            R.id.caryear_from, R.id.caryear_to,
            R.id.distance_from, R.id.distance_to,
            R.id.price_from,R.id.price_to};

    ArrayAdapter<String> setspinneradapter[] = new ArrayAdapter[10];

    //테스트
    String[] test = {"테스트1","테스트2","테스트3"};

    //로그인 여부 체크
    Boolean islogin = false;
    String notify_insert;
    ArrayList<String> notice_arr = new ArrayList<>();
    String userid;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        setTitle("알림설정");
        super.onCreate(saveInstanceState);
        setContentView(R.layout.notice);

        notify_insert = "http://"+getString(R.string.net_ip)+"/notify_insert.php";

        //Preference에 로그인 여부 확인
        islogin = PreferenceManager.getBoolean(getApplicationContext(), "islogin");
        userid = PreferenceManager.getString(getApplicationContext(), "userid");
        if (islogin == false){
            //로그인이 되어 있지 않으면 종료
            show();
        }

        //값을 받아오기
        networkthread net = new networkthread();
        net.site = "http://"+getString(R.string.net_ip)+"/notify_model.php";
        net.keyword = "model";

        net.start();

        try {
            net.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        notice_model = net.text();

        //스피너 설정
        for(int i=0; i<setspinnerid.length; i++){
            setspinner[i] = (Spinner)findViewById(setspinnerid[i]);

            if (i==0){
                setspinneradapter[i] = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notice_model);
            }else{
                setspinneradapter[i] = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, test);
            }
            setspinneradapter[i].setDropDownViewResource(android.R.layout.simple_list_item_1);
            setspinner[i].setAdapter(setspinneradapter[i]);
        }

        //스크롤뷰 리니어 레이아웃 설정
        notice_linear = findViewById(R.id.notice_linear);

        addbtn = findViewById(R.id.addnotice);
        //추가하기 버튼 클릭시
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //레이아웃을 추가
                dynamic_layout.add(new LinearLayout(getApplicationContext()));
                //글씨 레이어 9 : 버튼 레이어 3
                dynamic_layout.get(noticecount).setWeightSum(12f);
                //데이터 추가
                dynamic_text.add(new TextView(getApplicationContext()));
                LinearLayout.LayoutParams tmptxt = new LinearLayout.LayoutParams(
                        ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT);
                tmptxt.weight = 9f;
                tmptxt.gravity = Gravity.CENTER;
                dynamic_text.get(noticecount).setText(setspinner[0].getSelectedItem().toString() + setspinner[1].getSelectedItem().toString());
                dynamic_layout.get(noticecount).addView(dynamic_text.get(noticecount), tmptxt);

                //삭제버튼 추가
                dynamic_button.add(new Button((getApplicationContext())));
                LinearLayout.LayoutParams tmpbtn = new LinearLayout.LayoutParams(
                        ActionBar.LayoutParams.WRAP_CONTENT, ActionBar.LayoutParams.WRAP_CONTENT);
                tmpbtn.weight = 3f;
                tmpbtn.gravity = Gravity.CENTER;
                dynamic_button.get(noticecount).setText("삭제"+noticecount);
                dynamic_layout.get(noticecount).addView(dynamic_button.get(noticecount), tmpbtn);

                notice_linear.addView(dynamic_layout.get(noticecount));

                noticecount++;

                for(int i=0;i<dynamic_layout.size();i++){
                    int finalI = i;
                    dynamic_button.get(i).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            notice_linear.removeView(dynamic_layout.get(finalI));
                        }
                    });
                }

                int status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI) {
                    // 프로그래스바 보이게 처리
                    //findViewById(R.id.cpb).setVisibility(View.VISIBLE);

                    // get방식 파라미터 추가
                    HttpUrl.Builder urlBuilder = HttpUrl.parse(notify_insert).newBuilder();
                    urlBuilder.addQueryParameter("v", "1.0"); // 예시
                    String url = urlBuilder.build().toString();

                    // POST 파라미터 추가
                    RequestBody formBody = new FormBody.Builder()
                            .add("userid", userid)
                            .add("model", setspinner[0].getSelectedItem().toString())
                            .add("caryear_from", "3")
                            .add("caryear_to", "3")
                            .add("distance_from", "3")
                            .add("distance_to", "3")
                            .add("price_from", "3")
                            .add("price_to", "3")
                            .build();

                    // 요청 만들기
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder()
                            .url(url)
                            .post(formBody)
                            .build();

                    // 응답 콜백
                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(Call call, final Response response) throws IOException {

                            // 서브 스레드 Ui 변경 할 경우 에러
                            // 메인스레드 Ui 설정
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        // 프로그래스바 안보이게 처리
                                        //findViewById(R.id.cpb).setVisibility(View.GONE);

                                        if (!response.isSuccessful()) {
                                            // 응답 실패
                                            Log.i("tag", "응답실패");
                                            Toast.makeText(getApplicationContext(), "네트워크 문제 발생", Toast.LENGTH_SHORT).show();

                                        } else {
                                            // 응답 성공
                                            Log.i("tag", "응답 성공");
                                            final String responseData = response.body().string();
                                            Toast.makeText(getApplicationContext(),responseData,Toast.LENGTH_SHORT).show();
                                            if(responseData.equals("")) { } else { }
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });

                        }
                    });
                }else {
                    Toast.makeText(getApplicationContext(), "인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void show()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("로그인이 되어 있지 않음");
        builder.setMessage("로그인이 되어 있지 않아 알림 기능을 사용할 수 없습니다.\n 로그인을 해주세요.");
        builder.setPositiveButton("확인",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
//        builder.setNegativeButton("아니오",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(getApplicationContext(),"아니오를 선택했습니다.",Toast.LENGTH_LONG).show();
//                    }
//                });
        builder.setCancelable(false);
        builder.show();
    }
}
