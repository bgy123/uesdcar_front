package com.example.capstone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    //비트맵
    private Bitmap bitmap;
    //이미지 사용
    protected ArrayList<ImageView> imagebox = new ArrayList<>();
    //버튼
    private Button main_searchbutton;
    //이미지 주소
    protected ArrayList<String> box = new ArrayList<>();

    private BottomNavigationView bottomNavigationView; // 바텀네비게이션 뷰

    private long backpressedTime = 0;
    String mytoken = "";

    //네트워크 상태 받는 변수
    private int status;
    public boolean isconnect = true;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        setTitle("메인 화면");
        super.onCreate(saveInstanceState);
        setContentView(R.layout.main);

        //네트워크 확인 코드
        Boolean isnetwork;
        //String connectsite = "http://" + getString(R.string.net_ip);
        String connectsite = "http://1.1.1.1";
        Networkcheck netcheck = new Networkcheck();
        isnetwork = netcheck.Networkcheck(getApplicationContext(), connectsite);
        if(isnetwork){

        }else{
            show();
        }

        box.add("http://ci.encar.com/carpicture/carpicture03/pic3133/31330790_001.jpg?impolicy=widthRate&rw=700&cw=700&ch=525&cg=Center&wtmk=http://ci.encar.com/wt_mark/w_mark_03.png&t=20211118100214");
        box.add("https://ci.encar.com/carpicture/carpicture06/pic3036/30362016_001.jpg?impolicy=heightRate&rh=480&cw=640&ch=480&cg=Center&wtmk=https://ci.encar.com/wt_mark/w_mark_03.png&t=20210719102004");
        box.add("http://ci.encar.com/carpicture/carpicture02/pic3112/31122440_001.jpg?impolicy=heightRate&rh=653&cw=1160&ch=653&cg=Center&wtmk=http://ci.encar.com/wt_mark/w_mark_03.png&t=20211025114319");
        box.add("http://ci.encar.com/carpicture/carpicture07/pic3107/31070301_001.jpg?impolicy=heightRate&rh=653&cw=1160&ch=653&cg=Center&wtmk=http://ci.encar.com/wt_mark/w_mark_03.png&t=20211020095634");

        //캐시에 저장된 mytoken을 가져온다.
        mytoken = PreferenceManager.getString(getApplicationContext() ,"token");
        //저장된 값이 없다면 토큰을 발생시킨다.
        if(mytoken.equals(""))
        {
            //FCM으로 token값을 발생시키고 저장한다.
            FirebaseMessaging.getInstance().getToken()
                    .addOnCompleteListener(new OnCompleteListener<String>() {
                        @Override
                        public void onComplete(@NonNull Task<String> task) {
                            if (!task.isSuccessful()) {
                                return;
                            }

                            // Get new FCM registration token
                            String token = task.getResult();

                            // Log and toast
                            String msg = getString(R.string.msg_token_fmt, token);
                            mytoken = token;

                            //단 한번만 실행
                            FCM_token tn = new FCM_token();
                            String tnaddress ="http://" + getString(R.string.net_ip) + "/token_test.php?token="+ mytoken;
                            Log.d("myadress",tnaddress);

                            tn.site = tnaddress;
                            tn.start();
                            try {
                                tn.join();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }

                            Log.d("tokenaddress",token);
                            Toast.makeText(getApplicationContext(),"토큰주소:" + token,Toast.LENGTH_SHORT).show();

                            //Preference에 토큰 정보 저장
                            PreferenceManager.setString(getApplicationContext() ,"token", token);
                        }
                    });
        }

        //하단바 동작
        bottomNavigationView = findViewById(R.id.bottom_menu);
        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent nextIntent;
                switch (item.getItemId()){
                    case R.id.first_tab:
//                            nextIntent = new Intent(getApplicationContext(), Search.class);
//                            startActivity(nextIntent);
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        overridePendingTransition(0, 0);
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.second_tab:
                        RequestThread_main checknet_second = new RequestThread_main();
                        checknet_second.urlStr = connectsite;
                        if(checknet_second!=null && checknet_second.isAlive()){
                            checknet_second.interrupt();
                        }
                        checknet_second.start();
                        try {
                            checknet_second.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(isconnect==false){
                            show();
                        }else{
                            int status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                            if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI){
                                nextIntent = new Intent(getApplicationContext(), History.class);
                                startActivity(nextIntent);
                            }
                            else{
                                show();
                            }
                        }
                        break;
                    case R.id.third_tab:
                        RequestThread_main checknet_third = new RequestThread_main();
                        checknet_third.urlStr = connectsite;
                        if(checknet_third!=null && checknet_third.isAlive()){
                            checknet_third.interrupt();
                        }
                        checknet_third.start();
                        try {
                            checknet_third.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(isconnect==false){
                            show();
                        }else{
                            int status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                            if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI){
                                nextIntent = new Intent(getApplicationContext(), Favorite.class);
                                startActivity(nextIntent);
                            }
                            else{
                                show();
                            }
                        }
                        break;
                    case R.id.fourth_tab:
                        //알림
                        RequestThread_main checknet_fourth = new RequestThread_main();
                        checknet_fourth.urlStr = connectsite;
                        if(checknet_fourth!=null && checknet_fourth.isAlive()){
                            checknet_fourth.interrupt();
                        }
                        checknet_fourth.start();
                        try {
                            checknet_fourth.join();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(isconnect==false){
                            show();
                        }else{
                            int status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                            if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI){
                                nextIntent = new Intent(getApplicationContext(), Notice.class);
                                startActivity(nextIntent);
                            }
                            else{
                                show();
                            }
                        }
                        break;
                    case R.id.fifth_tab:
                        nextIntent = new Intent(getApplicationContext(), Menu.class);
                        startActivity(nextIntent);
                        break;
                }
                return true;
            }
        });

        //검색버튼가기
        main_searchbutton = findViewById(R.id.main_gosearch);
        main_searchbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectivityManager connManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { //23버전부터 사용가능
                    Network network = connManager.getActiveNetwork();

                    if(network == null){ //인터넷 연결이 안되어있으면,
                        //값실행
                        show();
                        Toast.makeText(getApplicationContext(), "인터넷 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Intent nextIntent = new Intent(getApplicationContext(), Search.class);
                        startActivity(nextIntent);
                    }
                }
            }
        });

        //이미지 반복 등록
        //이미지 부분
            /*
            imagebox.add(findViewById(R.id.main_image1));
            imagebox.add(findViewById(R.id.main_image2));
            imagebox.add(findViewById(R.id.main_image3));
            imagebox.add(findViewById(R.id.main_image4));
            */
        for(int i=1;i<5;i++){
            int getimage = getResources().getIdentifier("main_image"+i,"id",getPackageName());
            imagebox.add(findViewById(getimage));
        }

        //쓰레드 부분
        for(int i=0;i<4;i++){
            network net = new network();
            net.site = box.get(i);
            net.start();
            try {
                net.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            bitmap = net.bit();
            imagebox.get(i).setImageBitmap(bitmap);
        }
    }

    class RequestThread_main extends Thread {
        String urlStr;
        @Override
        public void run() {
            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if(conn != null){
                    conn.setConnectTimeout(5000); // 5초 동안 기다린 후 응답이 없으면 종료
                    conn.setRequestMethod("GET");
                    conn.setDoInput(true);
                    conn.setDoOutput(true);
                    int resCode = conn.getResponseCode();
                    conn.disconnect();
                }
            } catch (Exception e) {
                isconnect = false;
                e.printStackTrace();
            }
        }
    }

    public void getConnectivityStatus(Context context) {
        // 네트워크 연결 상태 확인하기 위한 ConnectivityManager 객체 생성
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm != null) {

            // 기기가 마시멜로우 버전인 Andorid 6 이상인 경우
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                // 활성화된 네트워크의 상태를 표현하는 객체
                NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());

                if (nc != null) {

                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        Toast.makeText(context, "와이파이 연결됨", Toast.LENGTH_SHORT).show();
                    } else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        Toast.makeText(context, "셀룰러 통신 사용", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, "인터넷 연결 안됨", Toast.LENGTH_SHORT).show();
                }

            } else {

                // 기기 버전이 마시멜로우 버전보다 아래인 경우
                // getActiveNetworkInfo -> API level 29에 디플리케이트 됨
                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                if (activeNetwork != null) {
                    // 연결된 네트워크 확인
                    if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                        Toast.makeText(context, "와이파이 연결됨", Toast.LENGTH_SHORT).show();
                    } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                        Toast.makeText(context, "셀룰러 통신 사용", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, "인터넷 연결 안됨", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


    //인터넷 연결 실패시 보여줄 화면
    //참조 : https://webnautes.tistory.com/1094
    void show()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("연결 실패");
        builder.setMessage("인터넷 연결이 되어있지 않거나\n 서버와 연결을 할 수 없습니다.");
        builder.setPositiveButton("확인",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //앱 자체를 종료
                        //finishAffinity();
                        //System.runFinalization();
                        //System.exit(0);
                    }
                });
//        builder.setNegativeButton("아니오",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(getApplicationContext(),"아니오를 선택했습니다.",Toast.LENGTH_LONG).show();
//                    }
//                });
        builder.setCancelable(false);
        builder.show();
    }
    //종료하기 두번 클릭
    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backpressedTime + 2000) {
            backpressedTime = System.currentTimeMillis();
            Toast.makeText(this, "\'뒤로\' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT).show();
        } else if (System.currentTimeMillis() <= backpressedTime + 2000) {
            finish();
        }
    }

    public void car_A(View view){
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(box.get(0))); startActivity(intent);
    }
    public void car_B(View view){
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(box.get(1))); startActivity(intent);
    }
    public void car_C(View view){
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(box.get(2))); startActivity(intent);
    }
    public void car_D(View view){
        Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse(box.get(3))); startActivity(intent);
    }
}