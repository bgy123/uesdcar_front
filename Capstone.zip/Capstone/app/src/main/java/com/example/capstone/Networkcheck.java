package com.example.capstone;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Networkcheck{

    Boolean isconnect = true;

    public boolean Networkcheck(Context context, String connectsite){
        int status = NetworkStatus.getConnectivityStatus(context);
        if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI) {

            RequestThread checknet = new RequestThread();
            checknet.urlStr = connectsite;
            if(checknet!=null && checknet.isAlive()){
                checknet.interrupt();
            }
            checknet.start();
            try {
                checknet.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            checknet.interrupt();
            isconnect = checknet.isconnected();
            if(isconnect==false){
                return false;
            }else{
                return true;
            }
        }
        else{
            return false;
        }
    }
}

//와이파이나 셀룰러 데이터 확인
class NetworkStatus {
    public static final int TYPE_WIFI = 1;
    public static final int TYPE_MOBILE = 2;
    public static final int TYPE_NOT_CONNECTED = 3;

    public static int getConnectivityStatus(Context context){ //해당 context의 서비스를 사용하기위해서 context객체를 받는다.
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if(networkInfo != null){
            int type = networkInfo.getType();
            if(type == ConnectivityManager.TYPE_MOBILE){//쓰리지나 LTE로 연결된것(모바일을 뜻한다.)
                return TYPE_MOBILE;
            }else if(type == ConnectivityManager.TYPE_WIFI){//와이파이 연결된것
                return TYPE_WIFI;
            }
        }
        return TYPE_NOT_CONNECTED;  //연결이 되지않은 상태
    }
}

//SQL 서버와 연결 확인
class RequestThread extends Thread {
    String urlStr;
    Boolean isconnect = true;
    @Override
    public void run() {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if(conn != null){
                conn.setConnectTimeout(5000); // 5초 동안 기다린 후 응답이 없으면 종료
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                int resCode = conn.getResponseCode();

                conn.disconnect();
            }
        } catch (Exception e) {
            isconnect = false;
            e.printStackTrace();
        }
    }
    public boolean isconnected(){
        return isconnect;
    }
}

class network extends Thread{
    public String site = "";
    Bitmap bitmap;
    public void run(){
        try {
            URL url = new URL(site);
            HttpURLConnection conn = null;
            conn = (HttpURLConnection) url.openConnection();

            //접속오류시 연결안함
            conn.setConnectTimeout(5000);
            conn.connect();
            try{
                //연결 성공, 이미지인경우
                InputStream aaa = conn.getInputStream(); //inputStream 값 가져오기
                bitmap = BitmapFactory.decodeStream(aaa); // Bitmap으로 반환
            }catch (Exception e){
                //연결은 성공했지만, 이미지가 아닌경우입니다.
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.bit();
    }
    public Bitmap bit(){
        return bitmap;
    }
}