package com.example.capstone;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.squareup.okhttp.Request;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Response;

public class Search extends AppCompatActivity {
    Button domestic_btn , overseas_btn, back;

    //국산 수입 Fragment
    Search_frag_L fragL;
    Search_frag_R fragR;

    //네트워크 상태 받는 변수
    private int status;
    private String connectsite;

    public boolean isconnect = true;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        setTitle("국산 및 수입차량 검색");
        super.onCreate(saveInstanceState);
        setContentView(R.layout.search);

        //프레그먼트 생성
        fragL = new Search_frag_L();
        fragR = new Search_frag_R();

        //국산 수입 버튼
        domestic_btn = findViewById(R.id.domestic);
        overseas_btn = findViewById(R.id.overseas);
        //뒤로가기버튼
        back = findViewById(R.id.search_gomain);

        //주소
        //"http://" + getString(R.string.net_ip);
        connectsite = "http://" + getString(R.string.net_ip);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        RequestThread checknet = new RequestThread();
        checknet.urlStr = connectsite;

        domestic_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checknet!=null && checknet.isAlive()){
                    checknet.interrupt();
                }
                RequestThread checknet = new RequestThread();
                checknet.urlStr = connectsite;

                checknet.start();

                try {
                    checknet.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                checknet.interrupt();
                if(isconnect==false){
                    show();
                }else{
                    //프레그먼트 실행
                    status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                    if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI){
                        getSupportFragmentManager().beginTransaction().replace(R.id.search_main_frame, fragL).commit();
                    }
                    else{
                        show();
                    }
                }
            }
        });
        overseas_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checknet!=null && checknet.isAlive()){
                    checknet.interrupt();
                }
                RequestThread checknet = new RequestThread();
                checknet.urlStr = connectsite;

                checknet.start();

                try {
                    checknet.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                checknet.interrupt();
                if(isconnect==false){
                    show();
                }else{
                    //프레그먼트 실행
                    status = NetworkStatus.getConnectivityStatus(getApplicationContext());
                    if(status == NetworkStatus.TYPE_MOBILE || status == NetworkStatus.TYPE_WIFI){
                        getSupportFragmentManager().beginTransaction().replace(R.id.search_main_frame, fragR).commit();
                    }
                    else{
                        show();
                    }
                }
            }
        });
    }

    //인터넷 연결 실패시 보여줄 화면
    //참조 : https://webnautes.tistory.com/1094
    void show()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("연결 실패");
        builder.setMessage("인터넷 연결이 되어있지 않거나\n 서버와 연결을 할 수 없습니다.\n 앱을 종료합니다.");
        builder.setPositiveButton("확인",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //앱 자체를 종료
                        finishAffinity();
                        System.runFinalization();
                        System.exit(0);
                    }
                });
//        builder.setNegativeButton("아니오",
//                new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(getApplicationContext(),"아니오를 선택했습니다.",Toast.LENGTH_LONG).show();
//                    }
//                });
        builder.setCancelable(false);
        builder.show();
    }

    public void onChangeFragment(int index){
        if(index == 0){
            getSupportFragmentManager().beginTransaction().replace(R.id.search_main_frame, fragL).commit();
        }else if(index ==1){
            getSupportFragmentManager().beginTransaction().replace(R.id.search_main_frame, fragR).commit();
        }
    }
}